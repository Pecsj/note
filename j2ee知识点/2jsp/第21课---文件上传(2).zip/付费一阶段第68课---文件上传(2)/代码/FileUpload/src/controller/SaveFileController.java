package controller;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.List;

public class SaveFileController extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
//            request.setCharacterEncoding("UTF-8");
            //创建一个工厂
            DiskFileItemFactory factory = new DiskFileItemFactory();
            factory.setSizeThreshold(1024000);//设置缓冲区大小
//            factory.setRepository(new File(""));//设置缓冲区位置
            //创建一个ServletFileUpload对象(构造方法中需要factory帮忙)
            ServletFileUpload upload = new ServletFileUpload(factory);
            upload.setSizeMax(102400000);
            //通过upload解析request对象(解析目的是因为请求携带的信息都在request对象中)
            List<FileItem> itemList = upload.parseRequest(request);
            //将list中所有的item元素遍历
            for(FileItem item : itemList){
                if(item.isFormField()){//是一个普通的组件
                    //注意不能使用request.getParameter("key");来获取   request对象已经被解析了
//                    System.out.println(request.getParameter("username"));
                    String key = item.getFieldName();//获取组件的name属性
                    //String value = item.getString();//获取组件的value属性
                    String value = item.getString("UTF-8");//使用重载方法传递处理字符集的key
                    System.out.println(key+"--"+value);
                }else{//是一个file文件
                    //???小悬念
                    String key = item.getFieldName();//获取组件的name属性
                    String realFileName= item.getName();//获取上传文件的真实文件名
//                    boolean result = this.testFileType(realFileName);
                    //如果传递的文件真实中文名有问题
                    //request.setCharacterEncoding("UTF-8");
                    //upload.setHeaderEncoding("UTF-8");
                    System.out.println(key+"--"+realFileName);
                    //桌面充当浏览器端  D://test充当服务器端
                    //如何获取根目录
                    this.getServletContext().getRealPath("/");
                    InputStream inputStream = item.getInputStream();//获取一个输入流  读取网络传递过来的文件内容
                    item.write(new File("D://test/"+realFileName));

                    //原生的方式实现文件的上传
//                    OutputStream outputStream = new FileOutputStream("D://test/"+realFileName);
//                    byte[] b = new byte[1024];
//                    int length = inputStream.read(b);
//                    while(length!=-1){
//                        outputStream.write(b,0,length);
//                        outputStream.flush();
//                        length = inputStream.read(b);
//                    }
//                    outputStream.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //自己设计一个方法
    private boolean testFileType(String fileName){
        String[] box = {"txt","doc","pdf","jpg","png"};
        for(int i=0;i<box.length;i++){
            if(fileName.endsWith(box[i])){
                return true;
            }
        }
        return false;
    }


    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req,resp);
    }
}
