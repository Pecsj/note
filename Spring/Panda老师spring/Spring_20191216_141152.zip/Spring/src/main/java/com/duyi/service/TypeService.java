package com.duyi.service;

public class TypeService {
}
