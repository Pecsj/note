package com.duyi.service;

import com.duyi.domain.User;

public class UserService {

    public void createUser(User user) {
        System.out.println("创建用户:" + user);
    }

    public void deleteUser(User user) {
        System.out.println("删除用户:" + user);
    }
}
