package com.duyi.controller;

import com.duyi.service.ClassService;
import com.duyi.service.TypeService;
import com.duyi.service.UserService;

public class CController {

    UserService userService;
    ClassService classService;
    TypeService typeService;

    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    public void setClassService(ClassService classService) {
        this.classService = classService;
    }

    public void setTypeService(TypeService typeService) {
        this.typeService = typeService;
    }
}
