package com.duyi;

import java.util.List;

public class Panda {

    int age;
    String str;
    List<Car> cars;

    public Panda(int age, String str) {
        this.age = age;
        this.str = str;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getStr() {
        return str;
    }

    public void setStr(String str) {
        this.str = str;
    }

    public List<Car> getCars() {
        return cars;
    }

    public void setCars(List<Car> cars) {
        this.cars = cars;
    }
}
