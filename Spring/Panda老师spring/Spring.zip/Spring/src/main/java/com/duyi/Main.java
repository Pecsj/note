package com.duyi;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class Main {

    public static ApplicationContext ctx;

    static {
        ctx = new ClassPathXmlApplicationContext("spel.xml");//spring初始化，读取配置文件，创建对象，组合成bean，存放到容器里。
//        ctx = new FileSystemXmlApplicationContext("file:/Users/changlifeng/Desktop/cat.xml");

        // 系统路径
        // 项目路径 —— 以项目路径为基础路径的。(没打包编译之前的，以项目为基础的路径)
        // classpath —— 以类路径作为基础路径的（打包编译之后，最根层包所在的路径，就是基础路径）

        //file: 代表从系统路径下寻找
        //classpath:代表从编译之后的最外层包所在路径下寻找
        //什么都不写，采用默认方式
        //ClassPathXmlApplicationContext 默认classpath:
        //FileSystemXmlApplicationContext 默认项目根路径
    }

    public static void main(String[] args) {

//        Panda panda = new Panda();
//        panda.setAge(18);
//        Panda panda = (Panda) ctx.getBean("panda");
//
//        System.out.println(panda.getAge());
//        System.out.println(panda.getStr());
//        System.out.println(panda.getCars().size());
//        System.out.println(panda.getCars().get("独轮").getName());
//        System.out.println(panda.getCars().get("三轮").getName());
//        System.out.println("null".equals(panda.getCar().name));

//        Panda panda3 = (Panda) ctx.getBean("panda3");
//        System.out.println(panda3.getAge());
//        System.out.println(panda3.getCars().get(0).getName());

//        Test a = (Test) ctx.getBean("test");
//        Test b = (Test) ctx.getBean("test");
//        System.out.println(a == b);

        Car car = (Car) ctx.getBean("car");
        System.out.println(car.toString());
        // lt <   gt >  eq == le <=  ge >=
//        System.out.println(100 ^ 2);//在java中^异或运算，在Spring中^是指数运算
//        System.out.println(Math.PI);
    }
}
