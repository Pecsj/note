package com.duing.springbootduing08actuator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDuing08ActuatorApplicationTests {

    @Test
    void contextLoads() {
    }

}
