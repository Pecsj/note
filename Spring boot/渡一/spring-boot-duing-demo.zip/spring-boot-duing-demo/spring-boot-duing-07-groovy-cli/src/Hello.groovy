
//groovy 通过变量内容猜测变量类型
def value = "hello world"
//value = 123
println(value)
println(value.class)
