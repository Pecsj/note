package com.duing.demo03.bean;

import lombok.Data;

@Data
public class Restaurant {

    private String boss;
    private String chef;
}
