package com.duing.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data@AllArgsConstructor
public class Guest {

    private String name;
    private String role;
}
