package com.duing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDuing06SwaggerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootDuing06SwaggerApplication.class, args);
    }

}
