drop table if exists guest;
create table guest(id int primary key auto_increment,name varchar,role varchar);