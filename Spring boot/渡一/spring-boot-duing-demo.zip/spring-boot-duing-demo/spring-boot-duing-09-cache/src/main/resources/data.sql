insert into guest(id,name,role) values (1,'黄晓明','店长');
insert into guest(id,name,role) values (2,'杨紫','茶水妹');