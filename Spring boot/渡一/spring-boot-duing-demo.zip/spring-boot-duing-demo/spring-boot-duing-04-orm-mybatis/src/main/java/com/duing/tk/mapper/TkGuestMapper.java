package com.duing.tk.mapper;

import com.duing.model.Guest;
import tk.mybatis.mapper.common.Mapper;

public interface TkGuestMapper extends Mapper<Guest> {
}
