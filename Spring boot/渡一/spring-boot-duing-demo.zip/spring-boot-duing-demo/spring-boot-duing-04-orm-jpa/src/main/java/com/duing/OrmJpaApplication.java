package com.duing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrmJpaApplication {

    public static void main(String[] args) {
        SpringApplication.run(OrmJpaApplication.class, args);
    }

}
