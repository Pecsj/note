package com.duing.bean;

import lombok.Getter;
import lombok.Setter;

@Getter@Setter
public class Food {

    private String rice;
    private String meat;
    private String[] sauce;

}
