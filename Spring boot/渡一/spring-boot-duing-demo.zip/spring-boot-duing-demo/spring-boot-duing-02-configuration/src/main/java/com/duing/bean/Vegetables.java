package com.duing.bean;

import lombok.Data;


/**
 * 数据接收类
 */
@Data
public class Vegetables {

    private String potato;
    private String eggplant;
    private String greenpeper;

}
