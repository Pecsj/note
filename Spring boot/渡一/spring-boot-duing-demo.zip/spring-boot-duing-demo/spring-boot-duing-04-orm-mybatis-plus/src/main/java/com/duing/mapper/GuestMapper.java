package com.duing.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.duing.model.Guest;

public interface GuestMapper extends BaseMapper<Guest> {
}
