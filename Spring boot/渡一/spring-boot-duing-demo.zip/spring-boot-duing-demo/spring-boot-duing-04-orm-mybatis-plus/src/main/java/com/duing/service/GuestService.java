package com.duing.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.duing.model.Guest;

import java.util.List;

public interface GuestService extends IService<Guest> {

//    List<Guest> getGuests();

}
