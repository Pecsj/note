package com.duing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDuing05WarApplicationTests {

    @Test
    void contextLoads() {
    }

}
